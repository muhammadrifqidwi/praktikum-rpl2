/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rpl_pert4;

/**
 *
 * @author ASUS
 */
public class Rpl_pert4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
