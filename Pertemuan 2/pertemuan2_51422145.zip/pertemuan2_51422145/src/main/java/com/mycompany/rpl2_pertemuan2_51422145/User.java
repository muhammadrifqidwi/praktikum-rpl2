/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rpl2_pertemuan2_51422145;

/**
 *
 * @author mrifq
 */
public class User {
    String nama;
    String email;
    String npm;
    
    public void login() {
        System.out.println("User melakukan login");
    }
    
    public void logout() {
        System.out.println("User melakukan logout"); 
    }
}
