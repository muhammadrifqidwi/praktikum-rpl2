/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rpl2_pertemuan2_51422145;

/**
 *
 * @author mrifq
 */
public class Admin extends User{
    
    public void login() {
        System.out.println("Admin melakukan login");
    }
    
    public void logout() {
        System.out.println("Admin melakukan logout");
    }
    
    public void manageUser(){
        System.out.println("admin mengelola user!");
    }
    
}
