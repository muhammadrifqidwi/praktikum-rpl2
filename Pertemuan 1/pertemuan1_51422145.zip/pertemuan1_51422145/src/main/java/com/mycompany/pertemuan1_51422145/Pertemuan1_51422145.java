/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pertemuan1_51422145;

import java.util.Scanner;

/**
 *
 * @author mrifq
 */
public class Pertemuan1_51422145 {

    public static void main(String[] args) {
//        int a = 5;
//        int b = 10;
//        int hasil = a+b;
//        
//        System.out.println("Hasil akhirnya adalah : " + hasil);
        
//        Scanner input = new Scanner(System.in);
//        
//        System.out.print("Masukkan nama anda : ");
//        
//        String nama = input.nextLine();
//
//        System.out.println("Halo, " + nama);

//        for (int i = 0; i <=10; i++) {
//                System.out.println("Angka ke-" +i);
//          }
//
           int angka = 3;
           
           if(angka > 0) {
               System.out.println("Angka positif");
           } else if (angka <0) {
               System.out.println("Angka negatif");
           } else {
               System.out.println("Angka nol");
               
           }
    }
}
